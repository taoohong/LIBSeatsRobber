class Config():
    date = "tomorrow"