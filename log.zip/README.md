# 脚本使用方法

## 1.安装chrome浏览器

本次脚本开发基于chrome浏览器

windows下载地址：[点击下载](https://www.google.com/intl/zh-TW/chrome/thank-you.html?statcb=1&installdataindex=empty&defaultbrowser=0)

macOS下载地址：[点击下载](https://www.google.com/chrome/thank-you.html?statcb=1&installdataindex=empty&defaultbrowser=0)


## 2.查看chrome版本
![查看关于](https://github.com/TaoSupr/LIBSeatsRobber/blob/master/imgs/%E5%85%B3%E4%BA%8E.jpg?raw=true)

![查看关于](https://github.com/TaoSupr/LIBSeatsRobber/blob/master/imgs/%E5%85%B3%E4%BA%8E1.jpg?raw=true)

记录chrome版本号，比如我使用的是103.0.5060.134版本

## 3.安装chromedriver
在下载链接中，选择对应chrome版本的chromedriver

[下载链接](https://chromedriver.chromium.org/downloads)

下载好后，将chromedriver.exe置于python安装目录下

![查看关于](https://github.com/TaoSupr/LIBSeatsRobber/blob/master/imgs/Chromedriver.png?raw=true)

## 4.关于安装python
装不装都可以，取决于你是否想运行源码

## 5.运行程序
运行dist目录下的test.exe检测环境是否配置完毕

跳出百度页面即表示配置完成

配置完成后，即可运行dist目录下的robber.exe

请于每日18:00之前运行抢座程序